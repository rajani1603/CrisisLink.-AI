import { motion } from 'motion/react';
import { Radio, Bell, ShieldCheck, ArrowRight } from 'lucide-react';

export default function Solution() {
  const steps = [
    {
      icon: <Radio className="w-8 h-8 text-white" />,
      title: "SOS Trigger",
      desc: "One-tap alert from any device or auto-detected by AI",
      color: "bg-red-600"
    },
    {
      icon: <Bell className="w-8 h-8 text-white" />,
      title: "AI Analysis",
      desc: "Instant threat level grading and responder dispatch",
      color: "bg-orange-600"
    },
    {
      icon: <ShieldCheck className="w-8 h-8 text-white" />,
      title: "Protected",
      desc: "Live coordination ensures zero response overlap",
      color: "bg-emerald-600"
    }
  ];

  return (
    <section id="solution" className="py-24 bg-slate-900 border-y border-white/5 relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-red-950/20 via-transparent to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              className="text-red-500 font-bold tracking-[0.2em] uppercase text-sm mb-4"
            >
              The AI Advantage
            </motion.div>
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-4xl md:text-5xl font-bold text-white mb-8 tracking-tight"
            >
              Introducing CrisisLink AI: <br />
              <span className="text-red-500 italic">Unified Synergy.</span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-slate-400 text-lg mb-8 leading-relaxed"
            >
              CrisisLink AI bridges the gap between chaos and coordination. 
              Our platform uses multi-modal AI to analyze emergency signals, 
              instantly mobilizing the closest qualified responders with 
              centimeter-accurate floor maps.
            </motion.p>
            
            <div className="space-y-6">
              {steps.map((step, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.2 }}
                  className="flex items-start gap-4 p-4 rounded-xl bg-slate-950/50 border border-white/5"
                >
                  <div className={`p-3 rounded-lg ${step.color} grow-0 shrink-0`}>
                    {step.icon}
                  </div>
                  <div>
                    <h4 className="text-white font-bold mb-1">{step.title}</h4>
                    <p className="text-slate-400 text-sm">{step.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="lg:w-1/2 relative">
             <div className="relative z-10 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1000" 
                  alt="Security Operations Center"
                  className="w-full grayscale hover:grayscale-0 transition-all duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                
                {/* Micro UI Overlays */}
                <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity }}
                  className="absolute top-10 right-10 bg-red-600 p-4 rounded-xl shadow-lg border border-red-500 animate-pulse"
                >
                  <Bell className="text-white w-6 h-6" />
                </motion.div>
                
                <div className="absolute bottom-6 left-6 right-6">
                   <div className="bg-slate-900/90 backdrop-blur-md p-4 rounded-xl border border-white/10">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-red-500 uppercase tracking-widest">Active Incident</span>
                        <span className="text-xs text-slate-500">00:42 since trigger</span>
                      </div>
                      <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: '65%' }}
                          className="h-full bg-red-600"
                        />
                      </div>
                   </div>
                </div>
             </div>
             
             {/* Decorative glow */}
             <div className="absolute -top-10 -right-10 w-64 h-64 bg-red-600/20 rounded-full blur-[100px] z-0" />
          </div>
        </div>
      </div>
    </section>
  );
}
