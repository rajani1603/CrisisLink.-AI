import { motion } from 'motion/react';
import { 
  Smartphone, 
  BrainCircuit, 
  Navigation2, 
  Map, 
  MessageSquareWarning, 
  Activity, 
  Zap
} from 'lucide-react';

const features = [
  {
    icon: <Smartphone />,
    title: "Omni-SOS Button",
    description: "Multi-trigger activation: Physical buttons, watch apps, voice commands, or gesture shortcuts."
  },
  {
    icon: <BrainCircuit />,
    title: "AI Threat Grading",
    description: "Gemini-powered analysis of audio/video feeds to filter false alarms and grade incident severity."
  },
  {
    icon: <Navigation2 />,
    title: "Indoor Tracking",
    description: "Precision geolocation using Wi-Fi RTT and UWB, providing exact room and floor data."
  },
  {
    icon: <Map />,
    title: "Smart Navigation",
    description: "Dynamic routing for responders that avoids hazards and congestion in real-time."
  },
  {
    icon: <MessageSquareWarning />,
    title: "Offline SMS Alerts",
    description: "Proprietary mesh communication protocol that works even when Wi-Fi and 5G are compromised."
  },
  {
    icon: <Activity />,
    title: "Vital Monitoring",
    description: "Optional wearables integration to monitor the victim's heart rate and stress levels live."
  }
];

export default function Features() {
  return (
    <section id="features" className="py-24 bg-slate-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div className="max-w-2xl">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="text-red-500 font-bold tracking-[0.2em] uppercase text-sm mb-4"
            >
              System Capabilities
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">
              Enterprise-grade <br />
              <span className="text-slate-500">Defense Stack.</span>
            </h2>
          </div>
          <p className="text-slate-400 max-w-sm mb-2 italic">
            Built to endure the most critical seconds with 99.99% uptime and low-latency failovers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              whileHover={{ y: -5 }}
              className="group p-8 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/[0.08] hover:border-red-600/30 transition-all cursor-default"
            >
              <div className="w-12 h-12 rounded-lg bg-red-600/10 flex items-center justify-center text-red-500 mb-6 group-hover:bg-red-600 group-hover:text-white transition-all duration-300 shadow-[inset_0_0_10px_rgba(220,38,38,0.1)] group-hover:shadow-[0_0_20px_rgba(220,38,38,0.5)]">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-3 flex items-center gap-2">
                {feature.title}
                <Zap className="w-4 h-4 text-orange-500 opacity-0 group-hover:opacity-100 transition-opacity" />
              </h3>
              <p className="text-slate-400 leading-relaxed text-sm">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Background patterns */}
      <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>
    </section>
  );
}
