import { ShieldCheck, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-950 pt-24 pb-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <ShieldCheck className="w-8 h-8 text-red-600" />
              <span className="text-xl font-bold tracking-tighter text-white uppercase">
                CRISIS<span className="text-red-600 tracking-normal">LINK</span> AI
              </span>
            </div>
            <p className="text-slate-500 max-w-sm mb-6">
              Winning solution for CrisisNav 2024 Global Hackathon. 
              Engineering extreme reliability for high-stakes human factors.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all">
                <Globe className="w-5 h-5"/>
              </a>
              <a href="#" className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all">
                <Mail className="w-5 h-5"/>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-white font-bold mb-6">Solution</h4>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li><a href="#" className="hover:text-red-500">Enterprise SOC</a></li>
              <li><a href="#" className="hover:text-red-500">Facility Mesh</a></li>
              <li><a href="#" className="hover:text-red-500">AI Integration</a></li>
              <li><a href="#" className="hover:text-red-500">Responder SDK</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Hackathon Team</h4>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li><a href="#" className="hover:text-slate-300">Case Study</a></li>
              <li><a href="#" className="hover:text-slate-300">Technical Paper</a></li>
              <li><a href="#" className="hover:text-slate-300">Live Demo Kit</a></li>
              <li><a href="#" className="hover:text-slate-300">GitHub Repo</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-600 font-mono">
          <p>© 2024 CRISISLINK AI PROTOTYPE. NO REAL RESCUE GUARANTEED IN DEMO MODE.</p>
          <div className="flex gap-8">
            <a href="#">PRIVACY</a>
            <a href="#">TERMS</a>
            <a href="#">SECURITY</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function Globe(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="2" x2="22" y1="12" y2="12" />
      <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
    </svg>
  )
}
