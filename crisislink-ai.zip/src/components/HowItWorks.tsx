import { motion } from 'motion/react';
import { MousePointer2, Cpu, MapPin, Zap } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      title: "Activate",
      desc: "SOS trigger sends instant signal with identity and UWB location data.",
      icon: <MousePointer2 className="w-6 h-6" />,
      tag: "STEP 01"
    },
    {
      title: "Analyze",
      desc: "AI identifies threat type and matches current shift assignments.",
      icon: <Cpu className="w-6 h-6" />,
      tag: "STEP 02"
    },
    {
      title: "Route",
      desc: "Responders receive head-up display routing to the exact room.",
      icon: <MapPin className="w-6 h-6" />,
      tag: "STEP 03"
    },
    {
      title: "Solve",
      desc: "Incident closed with auto-generated AI summary and log history.",
      icon: <Zap className="w-6 h-6" />,
      tag: "STEP 04"
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-slate-900 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-red-500 font-bold tracking-[0.2em] uppercase text-sm mb-4"
          >
            Tactical Workflow
          </motion.div>
          <h2 className="text-4xl font-bold text-white mb-4">Zero Friction Response</h2>
        </div>

        <div className="grid md:grid-cols-4 gap-8 relative">
          {/* Connector Line (Desktop) */}
          <div className="hidden md:block absolute top-[2.25rem] left-[10%] right-[10%] h-[1px] bg-gradient-to-r from-transparent via-red-600/30 to-transparent" />

          {steps.map((step, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.15 }}
              className="relative text-center flex flex-col items-center"
            >
              <div className="w-12 h-12 rounded-full bg-slate-950 border border-red-600/40 flex items-center justify-center text-red-500 mb-6 relative z-10 shadow-[0_0_15px_rgba(220,38,38,0.2)]">
                {step.icon}
              </div>
              <div className="text-red-500 font-mono text-[10px] tracking-widest mb-2 opacity-50">
                {step.tag}
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{step.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed max-w-[200px]">
                {step.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
