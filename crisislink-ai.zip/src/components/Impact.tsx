import { motion } from 'motion/react';
import { Globe, Heart, ShieldCheck } from 'lucide-react';

export default function Impact() {
  const stats = [
    { label: "Critical Response", value: "-45%", sub: "Time Reduction", icon: <ShieldCheck className="text-red-500" /> },
    { label: "Industry Reach", value: "1.2k+", sub: "Managed Sites", icon: <Globe className="text-blue-500" /> },
    { label: "Safety Score", value: "99%", sub: "User Trust Rate", icon: <Heart className="text-emerald-500" /> },
  ];

  return (
    <section className="py-24 bg-slate-900 overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2">
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="text-red-500 font-bold tracking-[0.2em] uppercase text-sm mb-4"
            >
              The Real-World Impact
            </motion.div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 tracking-tight">
              Scaling safety <br />
              <span className="text-red-600">across industries.</span>
            </h2>
            <p className="text-slate-400 text-lg leading-relaxed mb-8">
              While our roots are in luxury hospitality, CrisisLink AI's modular 
              architecture adapts to hospitals, stadiums, and industrial sites. 
              We don't just send alerts; we orchestrate high-stakes survival.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
               {['Hotels & Resorts', 'Hospitals', 'Concert Stadiums', 'Corporate HQ'].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-white font-medium p-3 rounded-lg bg-white/5 border border-white/5">
                    <div className="w-1.5 h-1.5 rounded-full bg-red-600" />
                    {item}
                  </div>
               ))}
            </div>
          </div>

          <div className="lg:w-1/2 grid grid-cols-1 gap-6">
            {stats.map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="theme-card flex items-center justify-between group hover:border-red-600/20"
              >
                <div>
                  <div className="theme-label mb-1">{stat.label}</div>
                  <div className="text-4xl font-extrabold text-white mb-1 group-hover:text-red-500 transition-colors tracking-tighter">{stat.value}</div>
                  <div className="text-slate-500 text-xs tracking-tight font-medium uppercase">{stat.sub}</div>
                </div>
                <div className="p-4 rounded-xl bg-white/5 group-hover:bg-red-600/10 transition-colors">
                  {stat.icon}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
