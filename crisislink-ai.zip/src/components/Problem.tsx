import { motion } from 'motion/react';
import { AlertTriangle, Clock, MapPinOff, Users } from 'lucide-react';

export default function Problem() {
  const painPoints = [
    {
      icon: <Clock className="w-10 h-10 text-red-500" />,
      title: "Delayed Notification",
      description: "Critical minutes are lost navigating complex phone menus and fragmented communication channels."
    },
    {
      icon: <MapPinOff className="w-10 h-10 text-red-500" />,
      title: "Location Blindness",
      description: "Responders often lack precise floor-level coordinates in large hotels or corporate campuses."
    },
    {
      icon: <Users className="w-10 h-10 text-red-500" />,
      title: "Uncoordinated Response",
      description: "Security teams, medical staff, and police often operate without a unified real-time operating picture."
    }
  ];

  return (
    <section id="problem" className="py-24 bg-slate-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-red-500 font-bold tracking-[0.2em] uppercase text-sm mb-4"
          >
            The Crisis Gap
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold text-white mb-6"
          >
            Traditional response is <span className="text-red-600">failing</span>.
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="max-w-2xl mx-auto text-slate-400 text-lg"
          >
            In large-scale hospitality and corporate environments, fragmented 
            communication leads to catastrophic delays when every second counts.
          </motion.p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {painPoints.map((point, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="p-8 rounded-2xl bg-slate-900/50 border border-white/5 hover:border-red-600/30 transition-colors group"
            >
              <div className="mb-6 transform group-hover:scale-110 transition-transform duration-300">
                {point.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-4">{point.title}</h3>
              <p className="text-slate-400 leading-relaxed">
                {point.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Warning Board */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          className="mt-20 p-8 rounded-3xl bg-gradient-to-br from-red-600/20 to-transparent border border-red-600/20 flex flex-col md:flex-row items-center gap-8"
        >
          <div className="p-4 rounded-full bg-red-600/20">
            <AlertTriangle className="w-12 h-12 text-red-500" />
          </div>
          <div>
            <h4 className="text-2xl font-bold text-white mb-2">The Hospitality Risk</h4>
            <p className="text-slate-300 max-w-4xl">
              Hotels face unique challenges: high guest turnover, complex layouts, 
              and the need for discreet yet rapid security. Current panic buttons are 
              often static, providing zero context to responders.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
