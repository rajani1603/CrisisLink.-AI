import { motion } from 'motion/react';
import { 
  AlertCircle, 
  Map as MapIcon, 
  Users, 
  Activity, 
  MessageSquare, 
  Menu,
  ChevronRight,
  Shield
} from 'lucide-react';
import { cn } from '../lib/utils';

export default function DemoDashboard() {
  return (
    <section id="demo" className="py-24 bg-slate-950 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-white mb-4"
          >
            Live Command & Control
          </motion.h2>
          <p className="text-slate-400">The central nervous system of your facility's safety.</p>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative bg-[#0a0a0a] rounded-xl border border-white/10 overflow-hidden min-h-[600px] flex flex-col md:flex-row shadow-2xl"
        >
          {/* Sidebar */}
          <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-white/5 bg-black/50 p-4 space-y-2 shrink-0">
            <div className="flex justify-between items-center px-4 py-2 mb-4 border-b border-white/10">
              <span className="theme-label !text-slate-100">OPERATIONAL_VIEW_V.2.0</span>
              <div className="flex gap-1">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                <div className="w-2 h-2 rounded-full bg-slate-700"></div>
              </div>
            </div>
            
            {[
              { icon: <Activity className="w-4 h-4"/>, label: "Live Feed", active: true },
              { icon: <AlertCircle className="w-4 h-4"/>, label: "Incidents", count: 2 },
              { icon: <MapIcon className="w-4 h-4"/>, label: "Heatmap" },
              { icon: <Users className="w-4 h-4"/>, label: "Responders", count: 8 },
            ].map((item, idx) => (
              <div 
                key={idx}
                className={cn(
                  "flex items-center justify-between px-3 py-2 rounded text-[10px] uppercase font-bold tracking-widest transition-colors cursor-pointer",
                  item.active ? "bg-red-500 text-white" : "text-slate-500 hover:text-white hover:bg-white/5"
                )}
              >
                <div className="flex items-center gap-3">
                  {item.icon}
                  {item.label}
                </div>
                {item.count && (
                  <span className="px-1.5 py-0.5 rounded bg-black/20 text-white text-[8px] font-bold">
                    {item.count}
                  </span>
                )}
              </div>
            ))}
          </div>

          {/* Main Area */}
          <div className="flex-1 flex flex-col min-w-0">
            {/* Top Bar */}
            <div className="h-10 border-b border-white/5 flex items-center justify-between px-6 bg-white/[0.02]">
              <div className="flex items-center gap-4">
                <span className="theme-label opacity-60">System Status: Connected</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
              </div>
              <div className="theme-label opacity-40">
                 16:42:08.SOC2
              </div>
            </div>

            {/* Content Split */}
            <div className="flex-1 flex flex-col xl:flex-row min-h-0 overflow-auto">
              {/* Map Placeholder */}
              <div className="flex-1 min-h-[300px] relative bg-[#050505]">
                 <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#1a1a1a_1px,transparent_1px)] [background-size:20px_20px]" />
                 
                 {/* Mock Map Markers */}
                 <div className="absolute top-1/3 left-1/4 group cursor-pointer">
                    <div className="w-10 h-10 border-2 border-red-500 rounded-full animate-[ping_2s_infinite] absolute inset-0"></div>
                    <div className="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center relative shadow-lg">
                      <span className="text-[10px] font-bold">SOS</span>
                    </div>
                    <div className="absolute top-12 left-0 bg-black/95 backdrop-blur-md p-2 rounded border border-white/20 whitespace-nowrap z-20">
                       <div className="theme-label !text-red-500 mb-1">RM 402: MEDICAL</div>
                       <div className="text-[8px] text-slate-400 font-mono">ETA RESPONDERS: 1M 22S</div>
                    </div>
                 </div>
                 
                 <div className="absolute top-[40%] right-[30%] w-2 h-2 bg-emerald-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.8)]" />
                 <div className="absolute bottom-[30%] left-[45%] w-2 h-2 bg-blue-500 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.8)]" />
              </div>

              {/* Feed/Activity Sidebar */}
              <div className="w-full xl:w-80 border-t xl:border-t-0 xl:border-l border-white/5 bg-black/20 p-4 shrink-0 flex flex-col gap-3 overflow-auto">
                <h4 className="theme-label !text-red-400 pb-2 border-b border-white/5">Digital Intake Feed</h4>
                
                <div className="space-y-2">
                  {[
                    { type: 'INCIDENT', title: 'Confirmed Sos #402', time: '14:22', level: 'CRITICAL', color: 'text-red-500' },
                    { type: 'NETWORK', title: 'Mesh Link Optimized', time: '14:21', level: 'INFO', color: 'text-blue-400' },
                    { type: 'SYSTEM', title: 'Dispatch Auth Check', time: '14:20', level: 'AUTO', color: 'text-slate-500' },
                  ].map((log, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={cn(
                        "p-2 rounded border border-white/5 bg-white/[0.02] flex flex-col gap-1 transition-all hover:bg-white/5",
                        log.level === 'CRITICAL' && "border-l-2 border-l-red-500 bg-red-950/20"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <span className={cn("text-[9px] font-bold uppercase tracking-widest", log.color)}>{log.type}</span>
                        <span className="text-[9px] font-mono opacity-40">{log.time}</span>
                      </div>
                      <div className="text-[11px] text-white font-medium">{log.title}</div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-auto p-4 rounded-xl bg-red-600/10 border border-red-600/20 text-center">
                  <div className="theme-label !text-red-500 mb-1">EMERGENCY PROTOCOL</div>
                  <button className="w-full py-2 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 transition-colors">
                    Broadcast to All
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
