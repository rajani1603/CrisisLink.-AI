import { motion } from 'motion/react';
import { Database, Cpu, Layout, Map as MapIcon } from 'lucide-react';

export default function TechStack() {
  const techs = [
    { name: "React 19", icon: <Layout className="text-blue-400" /> },
    { name: "Gemini Pro", icon: <Cpu className="text-purple-400" /> },
    { name: "Firebase", icon: <Database className="text-orange-400" /> },
    { name: "Google Maps", icon: <MapIcon className="text-emerald-400" /> },
  ];

  return (
    <section className="py-24 bg-slate-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-2xl font-bold text-white mb-12">Hardened Technology Core</h2>
          <div className="flex flex-wrap justify-center gap-8 md:gap-16">
            {techs.map((tech, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center gap-3 px-4 py-2 rounded border border-white/10 bg-white/[0.02] grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all font-mono"
              >
                {tech.icon}
                <span className="text-white text-xs font-bold tracking-tight">{tech.name}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
